// Example of generated DbContext. Use Scaffold-DbContext -Force to regenerate.
using Microsoft.EntityFrameworkCore;
namespace DatabaseFirstEmployeeManagement.Models;

public partial class TrainingDBContext : DbContext
{
    public TrainingDBContext(DbContextOptions<TrainingDBContext> options) : base(options) { }
    public virtual DbSet<Employee> Employees { get; set; }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Employee>(entity =>
        {
            entity.HasKey(e => e.EmployeeId);
            entity.ToTable("Employees");
            entity.Property(e => e.EmployeeName).HasMaxLength(100);
            entity.Property(e => e.Department).HasMaxLength(100);
            entity.Property(e => e.Salary).HasColumnType("decimal(12, 2)");
        });
        OnModelCreatingPartial(modelBuilder);
    }
    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
