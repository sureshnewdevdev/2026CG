// Example of a class produced by EF Core reverse engineering.
// Regenerate from the database with Scaffold-DbContext when the schema changes.
namespace DatabaseFirstEmployeeManagement.Models;

public partial class Employee
{
    public int EmployeeId { get; set; }
    public string EmployeeName { get; set; } = null!;
    public string Department { get; set; } = null!;
    public decimal Salary { get; set; }
}
