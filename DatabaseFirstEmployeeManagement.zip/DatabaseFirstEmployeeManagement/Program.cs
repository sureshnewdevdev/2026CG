using DatabaseFirstEmployeeManagement.Models;
using DatabaseFirstEmployeeManagement.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

var config = new ConfigurationBuilder()
    .SetBasePath(AppContext.BaseDirectory)
    .AddJsonFile("appsettings.json", optional: false)
    .Build();
var connectionString = config.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("ConnectionStrings:DefaultConnection is missing.");
var options = new DbContextOptionsBuilder<TrainingDBContext>()
    .UseSqlServer(connectionString)
    .Options;

try
{
    using var db = new TrainingDBContext(options);
    if (!db.Database.CanConnect())
    {
        Console.WriteLine("Cannot connect to TrainingDB. Check SQL Server and appsettings.json.");
        return;
    }
}
catch (Exception ex)
{
    Console.WriteLine($"Connection error: {ex.GetBaseException().Message}");
    return;
}

var service = new EmployeeService(options);
while (true)
{
    Console.WriteLine("\n===== EMPLOYEE MANAGEMENT =====");
    Console.WriteLine("1. Add employee");
    Console.WriteLine("2. View all employees");
    Console.WriteLine("3. View employee by ID");
    Console.WriteLine("4. Modify employee");
    Console.WriteLine("5. Remove employee");
    Console.WriteLine("0. Exit");
    Console.Write("Choose: ");
    var choice = Console.ReadLine()?.Trim();
    if (choice == "0") break;
    try
    {
        switch (choice)
        {
            case "1":
            {
                var name = ReadRequired("Employee name: ");
                var department = ReadRequired("Department: ");
                var salary = ReadSalary("Salary: ");
                int id = service.Add(name, department, salary);
                Console.WriteLine($"Employee added. New ID: {id}");
                break;
            }
            case "2":
            {
                var employees = service.GetAll();
                if (employees.Count == 0) Console.WriteLine("No employees found.");
                foreach (var e in employees) PrintEmployee(e);
                break;
            }
            case "3":
            {
                var employee = service.GetById(ReadId());
                if (employee is null) Console.WriteLine("Employee not found.");
                else PrintEmployee(employee);
                break;
            }
            case "4":
            {
                int id = ReadId();
                var existing = service.GetById(id);
                if (existing is null) { Console.WriteLine("Employee not found."); break; }
                PrintEmployee(existing);
                var name = ReadRequired("New name: ");
                var department = ReadRequired("New department: ");
                var salary = ReadSalary("New salary: ");
                Console.WriteLine(service.Update(id, name, department, salary)
                    ? "Employee updated." : "Employee no longer exists.");
                break;
            }
            case "5":
            {
                int id = ReadId();
                var existing = service.GetById(id);
                if (existing is null) { Console.WriteLine("Employee not found."); break; }
                PrintEmployee(existing);
                Console.Write("Type YES to confirm deletion: ");
                if (Console.ReadLine()?.Trim() == "YES")
                    Console.WriteLine(service.Delete(id) ? "Employee removed." : "Employee no longer exists.");
                else Console.WriteLine("Deletion cancelled.");
                break;
            }
            default:
                Console.WriteLine("Invalid option.");
                break;
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Operation failed: {ex.GetBaseException().Message}");
    }
}

static string ReadRequired(string prompt)
{
    while (true)
    {
        Console.Write(prompt);
        string? value = Console.ReadLine()?.Trim();
        if (!string.IsNullOrWhiteSpace(value) && value.Length <= 100) return value;
        Console.WriteLine("Enter 1-100 characters.");
    }
}
static int ReadId()
{
    while (true)
    {
        Console.Write("Employee ID: ");
        if (int.TryParse(Console.ReadLine(), out int id) && id > 0) return id;
        Console.WriteLine("Enter a positive whole number.");
    }
}
static decimal ReadSalary(string prompt)
{
    while (true)
    {
        Console.Write(prompt);
        if (decimal.TryParse(Console.ReadLine(), out var salary) && salary >= 0 && salary <= 9999999999.99m)
            return salary;
        Console.WriteLine("Enter a non-negative salary up to 9999999999.99.");
    }
}
static void PrintEmployee(Employee e) =>
    Console.WriteLine($"ID: {e.EmployeeId} | Name: {e.EmployeeName} | Department: {e.Department} | Salary: {e.Salary:N2}");
