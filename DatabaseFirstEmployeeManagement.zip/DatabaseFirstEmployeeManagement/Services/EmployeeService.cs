using DatabaseFirstEmployeeManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace DatabaseFirstEmployeeManagement.Services;

public class EmployeeService
{
    private readonly DbContextOptions<TrainingDBContext> _options;
    public EmployeeService(DbContextOptions<TrainingDBContext> options) => _options = options;

    public int Add(string name, string department, decimal salary)
    {
        using var db = new TrainingDBContext(_options);
        var employee = new Employee { EmployeeName = name, Department = department, Salary = salary };
        db.Employees.Add(employee);
        db.SaveChanges();
        return employee.EmployeeId;
    }

    public List<Employee> GetAll()
    {
        using var db = new TrainingDBContext(_options);
        return db.Employees.AsNoTracking().OrderBy(e => e.EmployeeId).ToList();
    }

    public Employee? GetById(int id)
    {
        using var db = new TrainingDBContext(_options);
        return db.Employees.AsNoTracking().FirstOrDefault(e => e.EmployeeId == id);
    }

    public bool Update(int id, string name, string department, decimal salary)
    {
        using var db = new TrainingDBContext(_options);
        var employee = db.Employees.Find(id);
        if (employee is null) return false;
        employee.EmployeeName = name;
        employee.Department = department;
        employee.Salary = salary;
        db.SaveChanges();
        return true;
    }

    public bool Delete(int id)
    {
        using var db = new TrainingDBContext(_options);
        var employee = db.Employees.Find(id);
        if (employee is null) return false;
        db.Employees.Remove(employee);
        db.SaveChanges();
        return true;
    }
}
