# Database-First Employee Management — .NET 8 Console App

## Prerequisites
- Visual Studio 2022 with .NET 8 SDK
- SQL Server Express (`.\SQLEXPRESS`) and SSMS
- NuGet package restore / internet access for first build

## Setup in Visual Studio
1. Open `DatabaseFirstEmployeeManagement.sln`.
2. Open SSMS, connect to `.\SQLEXPRESS` using Windows Authentication.
3. Execute `Database/CreateDatabase.sql`. This creates `TrainingDB` and `dbo.Employees` if absent.
4. Check `DatabaseFirstEmployeeManagement/appsettings.json`. Adjust the server name if needed.
5. Restore NuGet packages and build the solution.
6. Press Ctrl+F5 to run; choose menu options 1–5.

## Real Database-First workflow (regenerate the model from SQL Server)
The ZIP contains **representative scaffolded** `Models/Employee.cs` and `Models/TrainingDBContext.cs` so the project can be opened and built immediately. To generate these from *your actual database*, open Visual Studio Package Manager Console, set **Default project** to `DatabaseFirstEmployeeManagement`, and run:

```powershell
Scaffold-DbContext "Server=.\SQLEXPRESS;Database=TrainingDB;Trusted_Connection=True;TrustServerCertificate=True" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models -Context TrainingDBContext -Namespace DatabaseFirstEmployeeManagement.Models -ContextNamespace DatabaseFirstEmployeeManagement.Models -NoOnConfiguring -Force
```

`-Force` overwrites existing generated model files. Back up any custom changes first. The `-NoOnConfiguring` flag keeps the connection string out of generated source. The project reads it from `appsettings.json` at runtime.

If the table structure differs from the supplied SQL script, generated property names may differ and the CRUD service must be adjusted.

## Useful SQL checks
```sql
USE TrainingDB;
SELECT * FROM dbo.Employees ORDER BY EmployeeId;
```

## Menu
1. Add employee: name, department, salary -> INSERT
2. View all: SELECT
3. View by ID: SELECT with WHERE
4. Modify: UPDATE
5. Remove: DELETE after typing YES
0. Exit

## Troubleshooting
- `Named connection string ... not found`: use the direct connection string for scaffolding, as shown above.
- SQL Server connection failure: verify instance name, SQL Server service, Windows Authentication, and database existence.
- `Invalid object name 'Employees'`: run the SQL setup script in the correct instance.
- `appsettings.json` not found: ensure `CopyToOutputDirectory=PreserveNewest` in the project file.
- Regenerating models: prefer SQL changes first, then scaffold with `-Force`; avoid editing generated files directly.

This is a training sample. `TrustServerCertificate=True` is suitable for a controlled local lab, not a default production security choice.
