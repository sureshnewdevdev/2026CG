IF DB_ID(N'TrainingDB') IS NULL
    CREATE DATABASE TrainingDB;
GO
USE TrainingDB;
GO
IF OBJECT_ID(N'dbo.Employees', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Employees (
        EmployeeId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        EmployeeName NVARCHAR(100) NOT NULL,
        Department NVARCHAR(100) NOT NULL,
        Salary DECIMAL(12,2) NOT NULL,
        CONSTRAINT CK_Employees_Salary CHECK (Salary >= 0)
    );
END;
GO
SELECT * FROM dbo.Employees;
GO
